# Stratos

A very custom theme with very custom constraints.

## Setup

TBC

## Health warnings

Owing to a strong desire to have more social/professional links than the standard Facebook/Twitter there's currently a fair amount of hard coded nonsense included. I hope to reduce this somehow (maybe via a config file?) but at present there doesn't seem to be a straightforward way to integrate this into the admin portal thingy.